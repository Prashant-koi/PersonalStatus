# Personal Status Monitor - Quick Start Guide 
 
## What is this? 
Personal Status Monitor is a desktop widget that shows your current 
activity and thoughts on your portfolio website in real-time. 
 
## Quick Setup (5 minutes) 
 
1. **Double-click PersonalStatusMonitor.exe** 
   - Setup dialog will appear on first run 
 
2. **Enter your Portfolio API Endpoint:** 
   - Example: https://your-portfolio.vercel.app/api/status 
   - This is where your website receives status updates 
 
3. **Enter your API Key:** 
   - Example: psk_your_secure_random_key_here 
   - Use the same key in your website's environment variables 
 
4. **Click "Save & Start"** 
   - Settings are saved automatically 
   - App starts running in background 
 
5. **Find the system tray icon** 
   - Look for the app icon in your notification area 
   - Left-click to show/hide the status window 
   - Right-click for menu options 
 
## Features 
- Real-time thoughts sharing 
- Availability status (Free/Busy toggle) 
- Automatic app detection (shows what you're working with) 
- Secure API integration with your portfolio 
- System tray integration 
 
## Support 
For detailed documentation, see README.md 
 
Developed by Prasant Koirala | MIT License 
